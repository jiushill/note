package ysoserial;


/**
 * @author mbechler
 *
 */
public interface CustomPayloadArgs {

    
    String getPayloadArgs ();
    
}
