﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Amib.Threading;
using System.Threading;
using System.Net;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace webscanpath
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            showui();
        }

        public void showui() {
            int []threads = { 1, 3, 5, 10, 15, 20, 25, 50, 100, 300 };
            //box
            checkedListBox1.HorizontalScrollbar = true;
            checkedListBox1.ScrollAlwaysVisible = true;
            //comboBox
            foreach(var thread in threads) {
                comboBox1.Items.Add(thread);
            }
            //table
            listView1.GridLines = true;//表格是否显示网格线
            listView1.FullRowSelect = true;//是否选中整行
            listView1.View = View.Details;//设置显示方式
            listView1.Scrollable = true;//是否自动显示滚动条
            listView1.MultiSelect = false;//是否可以选择多行
            listView1.Columns.Add("状态码", 100, HorizontalAlignment.Center);
            listView1.Columns.Add("路径", 200, HorizontalAlignment.Center);
            listView1.Columns.Add("大小", 100, HorizontalAlignment.Center);
            listView1.Columns.Add("标题", 130, HorizontalAlignment.Center);
        }

        private void 复制ToolStripMenuItem_Click(object sender,EventArgs e) {
            MessageBox.Show("11");
            Clipboard.SetDataObject(this.listView1.SelectedItems.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = textBox1.Text.ToString();
            if (path.Length == 0)
            {
                MessageBox.Show("请输入字典路径");
            }
            else {
                if (!Directory.Exists(path))
                {
                    MessageBox.Show("字典路径不存在");
                }
                else {
                    var files = Directory.GetFiles(path, "*.txt");
                    foreach (var file in files) {
                        var name = file.Split('\\').Last();
                        checkedListBox1.Items.Add(name);
                    }
                }
            }
        }

        public void setfile(int id) {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;
            dialog.Title = "选择文件";
            dialog.Filter = "(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
                string []files = dialog.FileNames;
                foreach (var filename in files) {
                    string[] data = System.IO.File.ReadAllLines(filename);
                    foreach (var url in data) {
                        if (id == 1)
                        {
                            richTextBox1.Text += url + "\n";
                        }
                        else {
                            richTextBox2.Text += url + "\n";
                        }
                    }
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            setfile(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            setfile(2);
        }

        List<string> paths = new List<string>();
        List<string> urls = new List<string>();
        List<int> codes = new List<int>();
        List<string> names = new List<string>();
        int number;
        Thread t = null;
        SmartThreadPool stp = new SmartThreadPool();
        public void webscanrun() {
            Scan scan = new Scan();
            scan.uploadui += updateui;
            scan.TaskCallBask += taskcallbask;
            scan.errorpaths += errorpathsui;
            stp.MaxThreads = number;
            foreach (var u in urls)
            {
                calcs.calc += paths.Count;
                foreach (var ps in paths)
                {
                    string checkurl = u.TrimEnd('/') + '/' + ps.TrimStart('/');
                    stp.QueueWorkItem<string, List<string>, List<int>>(scan.webdir,checkurl, names, codes);
                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            //clear list:防止窗口不关闭时，第二次输入内容数据残留
            paths.Clear();
            urls.Clear();
            names.Clear();
            codes.Clear();
            number = int.Parse(comboBox1.Text);
            for (int calc = 0; calc < checkedListBox1.CheckedItems.Count; calc++) {
                string filename = checkedListBox1.GetItemText(checkedListBox1.CheckedItems[calc]);
                foreach (var d in System.IO.File.ReadAllLines(textBox1.Text+"\\"+filename)) {
                    paths.Add(d);
                }
            }

            foreach (var url in richTextBox1.Text.Split('\n')) {
                urls.Add(url);
            }

            foreach (var name in richTextBox2.Text.Split('\n'))
            {
                if (name.Count() != 0)
                {
                    names.Add(name);
                }
            }
            if (urls[urls.Count() - 1].Count() == 0)
            {
                urls.RemoveAt(urls.Count() - 1);
            }
            foreach (var code in textBox2.Text.Split(',')) {
                codes.Add(int.Parse(code));
            }
            label7.Text = "路径数量:" + paths.Count() + " url数量:" + urls.Count() + " 状态码数量:" + codes.Count() + " 关键字数量:" + names.Count() + " 线程速度:" + number.ToString();
            if (urls.Count != 0)
            {
                button4.Enabled = false;
                t = new Thread(webscanrun);
                t.Start();
            }
            else if(urls.Count==0||paths.Count==0){
                MessageBox.Show("待检测任务/路径数量为空");
            }
        }

        delegate void AsynUpdateUI(string code, string path, string size, string title);
        delegate void Aserrorpath(string path, string code);
        delegate void accomplishs();
        private void updateui(string code, string path, string size, string title) {
            if (InvokeRequired)
            {
                this.Invoke(new AsynUpdateUI(delegate (string code_, string path_, string size_, string title_)
                {
                    this.label7.Text = "正在扫描:" + path;
                    ListViewItem item = new ListViewItem();
                    item.SubItems.Clear();
                    item.SubItems[0].Text = code;
                    item.SubItems.Add(path);
                    item.SubItems.Add(size);
                    item.SubItems.Add(title);
                   this.listView1.Items.Add(item);


                }), code, path, size, title);
            }
            else {
                this.label7.Text = "正在扫描:" + path;
                ListViewItem item = new ListViewItem();
                item.SubItems.Clear();
                item.SubItems[0].Text = code;
                item.SubItems.Add(path);
                item.SubItems.Add(size);
                item.SubItems.Add(title);
                this.listView1.Items.Add(item);
            }
        }

        private void errorpathsui(string path, string code) {
            if (InvokeRequired)
            {
                this.Invoke(new Aserrorpath(delegate (string path_, string code_)
                {
                    this.label7.Text = "路径:" + path + code;
                }), path, code);
            }
            else {
                this.label7.Text = "路径:" + path + code;
            }
        }

        private void taskcallbask() {
            if (InvokeRequired)
            {
                this.Invoke(new accomplishs(delegate ()
                {
                    this.label7.Text = "任务完成";
                    this.button4.Enabled = true;
                }));
            }
            else {
                this.label7.Text = "任务完成";
                this.button4.Enabled = true;
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            t.Abort();
            stp.Cancel();
            MessageBox.Show("已停止任务");
            label7.Text = "已停止任务";
            label7.Refresh();
            button4.Enabled = true;
        }

        private void 复制ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                var data = listView1.SelectedItems[0].SubItems; //获取子项集合
                string text = "状态码:" + data[0].Text + " 路径:" + data[1].Text + " 大小:" + data[2].Text + " 标题:" + data[3].Text;
                Clipboard.SetDataObject(text);
            }
        }

        public void deleteitem(ListView box) {
            //需个函数回调才能完美清除掉集合的所有内容,lnk:https://www.cnblogs.com/insus/archive/2012/01/09/2317207.html
            for (int i = 0; i < box.Items.Count; i++)
            {
                box.Items.RemoveAt(i);
            }

            for (int i = 0; i < box.Items.Count; i++)
            {
                deleteitem(box);
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            deleteitem(listView1);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var savedialog =new System.Windows.Forms.SaveFileDialog();
            savedialog.Filter = "txt (*.txt)|*.txt";
            savedialog.FileName = "save.txt";
            savedialog.ShowDialog();
            if (savedialog.FileName.Length != 0) {
                FileStream fs = new FileStream(savedialog.FileName, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    var data = listView1.Items[i].SubItems;
                    string text = "状态码:" + data[0].Text + " 路径:" + data[1].Text + " 大小:" + data[2].Text + " 标题:" + data[3].Text;
                    sw.WriteLine(text);
                    sw.Flush();
                }
                fs.Close();
                fs.Close();
                MessageBox.Show("结果已经保存在:"+savedialog.FileName);
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (button4.Enabled == false)
            {
                t.Abort();
                stp.Cancel();
                MessageBox.Show("已停止任务");
                label7.Text = "已停止任务";
                label7.Refresh();
                button4.Enabled = true;
            }
        }
    }


    public static class calcs
    {
        public static int calc = 0;
        public static int calc2 = 0;
    }
    public class Scan {
        public delegate void Uploadui(string code,string path,string size,string title);
        public Uploadui uploadui;
        public delegate void errorpath(string path, string code);
        public errorpath errorpaths;
        public delegate void AccomlishTask();
        public AccomlishTask TaskCallBask;
    
        public  void webdir(string url,List<string> names,List<int> codes) {
            calcs.calc2 += 1;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url); //建立请求的URL
            HttpWebResponse res;
            try
            {
                res = (HttpWebResponse)req.GetResponse();
            }
            catch (WebException ex)
            {
                res = (HttpWebResponse)ex.Response;
            }
            Encoding enc = Encoding.GetEncoding("utf-8"); //定义返回内容编码为UTF-8
            if (res != null)
            {
                StreamReader sr = new StreamReader(res.GetResponseStream(), enc); //将返回内容编码转换为UTF-8
                string html = sr.ReadToEnd(); //读取编码转换后的html结果
                int statuscode = (int)res.StatusCode;
                if (codes.Contains(statuscode))
                {
                    string zz = @"<title>.*</title>";
                    var title = Regex.Match(html.ToString(), zz);
                    if (names.Count() != 0)
                    {
                        int id = 0;
                        foreach (var black in names)
                        {
                            if (html.Contains(black))
                            {
                                errorpaths(url, " 黑名单关键字:" + black);
                                id = 1;
                                break;
                            }
                        }

                        if (id != 1)
                        {
                            uploadui(statuscode.ToString(), url, html.Count().ToString(), title.Value.Replace("<title>", "").Replace("</title>", ""));
                        }
                    }
                    else {
                        uploadui(statuscode.ToString(), url, html.Count().ToString(), title.Value.Replace("<title>", "").Replace("</title>", ""));
                    }
    
                }
                else
                {
                    errorpaths(url, " 状态码:" + statuscode.ToString());
                }
            }
            else {
                errorpaths(url, " 请求异常:返回结果为null");
            }
            if (calcs.calc2 == calcs.calc) {
                TaskCallBask();
            }
        }
    }
}
